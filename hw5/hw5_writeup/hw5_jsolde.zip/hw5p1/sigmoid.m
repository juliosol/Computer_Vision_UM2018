function sa = sigmoid(a)
    %%%% FILL THIS UP WITH YOUR CODE
    % implement the sigmoid function
    sa = 1./(1+exp(-a));
    %%%%
end